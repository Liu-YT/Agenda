#include "AgendaUI.hpp"

int main(){
	cout << "test" << endl;
	AgendaUI test;
	test.AgendaShow();
	return 0;
}

